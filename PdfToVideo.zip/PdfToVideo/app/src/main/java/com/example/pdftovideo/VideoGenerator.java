package com.example.pdftovideo;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/** Turns PDF pages and images into an H.264 MP4 slideshow, entirely on-device. */
public class VideoGenerator {

    public static final int WIDTH = 1280;   // must be even
    public static final int HEIGHT = 720;   // must be even
    private static final int FPS = 10;
    private static final int BITRATE = 2_000_000;

    public interface Progress {
        void onProgress(int done, int total);
    }

    /** One slide: either an image Uri or one page of a cached PDF file. */
    public static class Slide {
        final Uri imageUri;
        final File pdfFile;
        final int pageIndex;

        Slide(Uri imageUri, File pdfFile, int pageIndex) {
            this.imageUri = imageUri;
            this.pdfFile = pdfFile;
            this.pageIndex = pageIndex;
        }
    }

    /** Expands the picked Uris into a flat list of slides (PDF -> one slide per page). */
    public static List<Slide> buildSlides(Context ctx, List<Uri> uris) throws Exception {
        List<Slide> slides = new ArrayList<>();
        ContentResolver cr = ctx.getContentResolver();
        int n = 0;
        for (Uri uri : uris) {
            String type = cr.getType(uri);
            if (type != null && type.equals("application/pdf")) {
                File cached = new File(ctx.getCacheDir(), "src_" + (n++) + ".pdf");
                try (InputStream in = cr.openInputStream(uri);
                     OutputStream out = new FileOutputStream(cached)) {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                }
                try (ParcelFileDescriptor pfd =
                             ParcelFileDescriptor.open(cached, ParcelFileDescriptor.MODE_READ_ONLY);
                     PdfRenderer renderer = new PdfRenderer(pfd)) {
                    for (int i = 0; i < renderer.getPageCount(); i++) {
                        slides.add(new Slide(null, cached, i));
                    }
                }
            } else {
                slides.add(new Slide(uri, null, 0));
            }
        }
        return slides;
    }

    /** Encodes the slides to an MP4 in the device's Movies folder and returns its Uri. */
    public static Uri generate(Context ctx, List<Slide> slides, int secondsPerSlide,
                               Progress progress) throws Exception {
        ContentResolver cr = ctx.getContentResolver();
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Video.Media.DISPLAY_NAME, "slideshow_" + System.currentTimeMillis() + ".mp4");
        cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/PdfToVideo");
        cv.put(MediaStore.Video.Media.IS_PENDING, 1);
        Uri outUri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
        if (outUri == null) throw new IllegalStateException("Could not create output file");

        MediaCodec codec = null;
        MediaMuxer muxer = null;
        ParcelFileDescriptor outPfd = null;
        boolean ok = false;
        try {
            outPfd = cr.openFileDescriptor(outUri, "w");
            muxer = new MediaMuxer(outPfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, WIDTH, HEIGHT);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            format.setInteger(MediaFormat.KEY_BIT_RATE, BITRATE);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, FPS);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            codec.start();

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int[] track = {-1};
            boolean[] muxerStarted = {false};
            long frameDurationUs = 1_000_000L / FPS;
            int framesPerSlide = Math.max(1, secondsPerSlide) * FPS;
            long pts = 0;

            for (int s = 0; s < slides.size(); s++) {
                Bitmap frame = renderSlide(ctx, slides.get(s));
                byte[][] yuv = toI420(frame);
                frame.recycle();

                for (int f = 0; f < framesPerSlide; f++) {
                    int inIdx;
                    while ((inIdx = codec.dequeueInputBuffer(10_000)) < 0) {
                        drain(codec, muxer, info, track, muxerStarted, false);
                    }
                    Image image = codec.getInputImage(inIdx);
                    fillImage(image, yuv);
                    codec.queueInputBuffer(inIdx, 0, WIDTH * HEIGHT * 3 / 2, pts, 0);
                    pts += frameDurationUs;
                    drain(codec, muxer, info, track, muxerStarted, false);
                }
                if (progress != null) progress.onProgress(s + 1, slides.size());
            }

            int inIdx;
            while ((inIdx = codec.dequeueInputBuffer(10_000)) < 0) {
                drain(codec, muxer, info, track, muxerStarted, false);
            }
            codec.queueInputBuffer(inIdx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            drain(codec, muxer, info, track, muxerStarted, true);
            ok = true;
        } finally {
            try { if (codec != null) { codec.stop(); codec.release(); } } catch (Exception ignored) { }
            try { if (muxer != null) { muxer.stop(); muxer.release(); } } catch (Exception ignored) { }
            try { if (outPfd != null) outPfd.close(); } catch (Exception ignored) { }
            if (ok) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Video.Media.IS_PENDING, 0);
                cr.update(outUri, done, null, null);
            } else {
                cr.delete(outUri, null, null);
            }
        }
        return outUri;
    }

    private static void drain(MediaCodec codec, MediaMuxer muxer, MediaCodec.BufferInfo info,
                              int[] track, boolean[] muxerStarted, boolean untilEos) {
        while (true) {
            int out = codec.dequeueOutputBuffer(info, untilEos ? 10_000 : 0);
            if (out == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!untilEos) return;
            } else if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track[0] = muxer.addTrack(codec.getOutputFormat());
                muxer.start();
                muxerStarted[0] = true;
            } else if (out >= 0) {
                ByteBuffer data = codec.getOutputBuffer(out);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                if (info.size > 0 && muxerStarted[0] && data != null) {
                    data.position(info.offset);
                    data.limit(info.offset + info.size);
                    muxer.writeSampleData(track[0], data, info);
                }
                codec.releaseOutputBuffer(out, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return;
            }
        }
    }

    /** Draws a slide letterboxed onto a WIDTH x HEIGHT bitmap. */
    private static Bitmap renderSlide(Context ctx, Slide slide) throws Exception {
        Bitmap src;
        boolean isPdf = slide.pdfFile != null;
        if (isPdf) {
            try (ParcelFileDescriptor pfd =
                         ParcelFileDescriptor.open(slide.pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
                 PdfRenderer renderer = new PdfRenderer(pfd);
                 PdfRenderer.Page page = renderer.openPage(slide.pageIndex)) {
                float scale = Math.min((float) WIDTH / page.getWidth(), (float) HEIGHT / page.getHeight()) * 2f;
                int w = Math.max(1, (int) (page.getWidth() * scale));
                int h = Math.max(1, (int) (page.getHeight() * scale));
                src = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                src.eraseColor(Color.WHITE);
                page.render(src, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            }
        } else {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = ctx.getContentResolver().openInputStream(slide.imageUri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int sample = 1;
            while (bounds.outWidth / sample > WIDTH * 2 || bounds.outHeight / sample > HEIGHT * 2) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            try (InputStream in = ctx.getContentResolver().openInputStream(slide.imageUri)) {
                src = BitmapFactory.decodeStream(in, null, opts);
            }
            if (src == null) throw new IllegalStateException("Could not decode image");
            src = applyExifRotation(ctx, slide.imageUri, src);
        }

        Bitmap out = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.drawColor(Color.BLACK);
        float scale = Math.min((float) WIDTH / src.getWidth(), (float) HEIGHT / src.getHeight());
        float dw = src.getWidth() * scale, dh = src.getHeight() * scale;
        Matrix m = new Matrix();
        m.postScale(scale, scale);
        m.postTranslate((WIDTH - dw) / 2f, (HEIGHT - dh) / 2f);
        canvas.drawBitmap(src, m, new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG));
        src.recycle();
        return out;
    }

    private static Bitmap applyExifRotation(Context ctx, Uri uri, Bitmap bmp) {
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            androidx.exifinterface.media.ExifInterface exif = new androidx.exifinterface.media.ExifInterface(in);
            int o = exif.getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 1);
            int deg = o == 6 ? 90 : o == 3 ? 180 : o == 8 ? 270 : 0;
            if (deg == 0) return bmp;
            Matrix m = new Matrix();
            m.postRotate(deg);
            Bitmap r = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            bmp.recycle();
            return r;
        } catch (Exception e) {
            return bmp;
        }
    }

    /** ARGB bitmap -> planar I420 arrays {Y, U, V}. */
    private static byte[][] toI420(Bitmap bmp) {
        int w = bmp.getWidth(), h = bmp.getHeight();
        int[] argb = new int[w * h];
        bmp.getPixels(argb, 0, w, 0, 0, w, h);
        byte[] y = new byte[w * h];
        byte[] u = new byte[(w / 2) * (h / 2)];
        byte[] v = new byte[(w / 2) * (h / 2)];
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                int c = argb[j * w + i];
                int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                y[j * w + i] = (byte) clamp(((66 * r + 129 * g + 25 * b + 128) >> 8) + 16);
                if ((j & 1) == 0 && (i & 1) == 0) {
                    int idx = (j / 2) * (w / 2) + (i / 2);
                    u[idx] = (byte) clamp(((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128);
                    v[idx] = (byte) clamp(((112 * r - 94 * g - 18 * b + 128) >> 8) + 128);
                }
            }
        }
        return new byte[][]{y, u, v};
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }

    /** Copies I420 data into the codec's Image, honouring row and pixel strides. */
    private static void fillImage(Image image, byte[][] yuv) {
        Image.Plane[] planes = image.getPlanes();
        for (int p = 0; p < 3; p++) {
            int pw = p == 0 ? WIDTH : WIDTH / 2;
            int ph = p == 0 ? HEIGHT : HEIGHT / 2;
            ByteBuffer buf = planes[p].getBuffer();
            int rowStride = planes[p].getRowStride();
            int pixelStride = planes[p].getPixelStride();
            byte[] src = yuv[p];
            for (int row = 0; row < ph; row++) {
                int base = row * rowStride;
                if (pixelStride == 1) {
                    buf.position(base);
                    buf.put(src, row * pw, pw);
                } else {
                    for (int col = 0; col < pw; col++) {
                        buf.put(base + col * pixelStride, src[row * pw + col]);
                    }
                }
            }
        }
        image.close();
    }
}
