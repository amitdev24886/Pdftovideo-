package com.example.pdftovideo;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private final List<Uri> picked = new ArrayList<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private Button btnPick, btnGenerate, btnOpen;
    private TextView tvSelection, tvStatus;
    private EditText etSeconds;
    private ProgressBar progress;
    private Uri resultUri;

    private final ActivityResultLauncher<String[]> picker =
            registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), uris -> {
                picked.clear();
                if (uris != null) picked.addAll(uris);
                tvSelection.setText(picked.isEmpty() ? "Nothing selected" : picked.size() + " file(s) selected");
                btnGenerate.setEnabled(!picked.isEmpty());
                btnOpen.setVisibility(View.GONE);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPick = findViewById(R.id.btnPick);
        btnGenerate = findViewById(R.id.btnGenerate);
        btnOpen = findViewById(R.id.btnOpen);
        tvSelection = findViewById(R.id.tvSelection);
        tvStatus = findViewById(R.id.tvStatus);
        etSeconds = findViewById(R.id.etSeconds);
        progress = findViewById(R.id.progress);

        btnPick.setOnClickListener(v -> picker.launch(new String[]{"application/pdf", "image/*"}));
        btnGenerate.setOnClickListener(v -> startGeneration());
        btnOpen.setOnClickListener(v -> {
            if (resultUri == null) return;
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(resultUri, "video/mp4");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        });
    }

    private void startGeneration() {
        int seconds = 3;
        try {
            seconds = Integer.parseInt(etSeconds.getText().toString().trim());
        } catch (NumberFormatException ignored) { }
        final int secondsPerSlide = Math.max(1, Math.min(seconds, 30));

        setBusy(true);
        tvStatus.setText("Preparing slides...");
        final List<Uri> inputs = new ArrayList<>(picked);

        executor.execute(() -> {
            try {
                List<VideoGenerator.Slide> slides = VideoGenerator.buildSlides(this, inputs);
                if (slides.isEmpty()) throw new IllegalStateException("No pages or images found");
                ui.post(() -> {
                    progress.setMax(slides.size());
                    progress.setProgress(0);
                    tvStatus.setText("Encoding " + slides.size() + " slide(s)...");
                });
                Uri out = VideoGenerator.generate(this, slides, secondsPerSlide, (done, total) ->
                        ui.post(() -> {
                            progress.setProgress(done);
                            tvStatus.setText("Encoded " + done + " / " + total);
                        }));
                ui.post(() -> {
                    resultUri = out;
                    tvStatus.setText("Done. Saved to Movies/PdfToVideo");
                    btnOpen.setVisibility(View.VISIBLE);
                    setBusy(false);
                });
            } catch (Exception e) {
                ui.post(() -> {
                    tvStatus.setText("Failed: " + e.getMessage());
                    setBusy(false);
                });
            }
        });
    }

    private void setBusy(boolean busy) {
        btnPick.setEnabled(!busy);
        btnGenerate.setEnabled(!busy && !picked.isEmpty());
        progress.setVisibility(busy ? View.VISIBLE : View.INVISIBLE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}
